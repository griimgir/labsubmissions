#include <search.h>
#include <server.h>

using namespace ucm;
// init isn't working but my code should work. There's an issue with how this file and I dont know how
//to fix this issue. I dont know why you have the data base in search.h instead of here.
//unable to test myself because of this.
//again init() is not working

int main(int argc, char** argv){

    // Do not delete this line. It initializes the data store.
    init();

    Server server(argc, argv);

    server.renderHTML("/", "index.html");

    server.route("/search", [&](const request& req, response& res){
        // Provide your code here. 
        // ucm::json temp;
        // temp["message"] = "It works!";
        // res.sendJSON(temp);

        ucm::json zoo;
        if(req.has_params({"q"})){
            std::string q = req.url_params.get("q");
            zoo = search(q);
            res.sendJSON(zoo);
        }
        else{
            zoo["check"] = "Default";
            zoo["result"] = getAll();
            res.sendJSON(zoo);
        }
    });

    server.run();
}
