#ifndef _SNOWHOUSE_H_JK_2013_06_28
#define _SNOWHOUSE_H_JK_2013_06_28

#include "stringize.h"
#include "constraints/constraints.h"
#include "fluent/fluent.h"
#include "assertionexception.h"
#include "assert.h"
#include "assertmacro.h"
#include "exceptions.h"

#endif

