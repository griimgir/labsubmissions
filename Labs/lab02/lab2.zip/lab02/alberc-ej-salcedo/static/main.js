//note: I recieved help from patrick in implementing search button and search
$(document).ready(function(){
	// The entire database should be displayed when your app starts
	// The Search button should be programmed to hit the /search endpoint along with the query string from the text box
	
		$("#SearchButton").click(function(){
			var input = $("#input").val();
			$.get("/search", {"q": input}, function(response){
				var sector = JSON.parse(response); //this is to display each animal in the grid
				var htmlCode = "";
				var data = sector["result"];	//animals in data base to be displayed
				var check = sector["check"];	//for if statements when user searches for something
				var index = 0;

				//default homepage which diplays the whole zoo
				if(check == "Empty"){
					for (var i in data){
						var theList = data[i];
						for (var j in theList){
							// console.log("Will display " + data[i][j]);
							//htmlCode += "<img style='width:200px' src='images/" + theList[j] + "'>";
							htmlCode = "<img style='width:200px' src='images/" + theList[j] + "'>";
							var pic = "#area" + index; //this implamentation is what patrick helped me with
							$(pic).html(htmlCode);

							index++;
						}
						//$("#area").html(htmlCode);
					}
				}
				else if(check == "Fail"){
					index = 0;
					htmlCode = "(" + input + ") was not found";
					for (var i in data){
						var theList = data[i];
						for (var j in theList){
							// console.log("Will display " + data[i][j]);
							//htmlCode += "<img style='width:200px' src='images/" + theList[j] + "'>";
							htmlCode = "";
							var pic = "#area" + index; //this implamentation is what patrick helped me with
							$(pic).html(htmlCode);

							index++;
						}
						//$("#area").html(htmlCode);
					}

				}
				else{
					for(var i in data){
						htmlCode = "<img style='width:200px' src='images/" + data[i] + "'>";

						var pic = "#area" + index;
						$(pic).html(htmlCode);

						index++;
					}
					for(var i in data){
						console.log(data);
						for(var j in data[i]){
							console.log(data[i]);
							htmlCode = "";
							
							var pic = "#area" + index;
							$(pic).html(htmlCode);
							
							index++;
						}
					}
				}

		});
	});

	$.get("/search", {}, function(response){
		var sector = JSON.parse(response); //this is to display each animal in the grid
		var htmlsector = "";
		var data = sector["result"];	//animals in data base to be displayed
		// var check = sector["check"];	//for if statements when user searches for something
		var index = 0;

		for (var i in data){
			var theList = data[i];
			
			for (var j in theList){
				// console.log("Will display " + data[i][j]);
				htmlsector = "<img style='width:200px' src='images/" + theList[j] + "'>"

				var pic = "area" + index;
				$(pic).html(htmlsector);

				index++;
			}
			//$("#area").html(htmlCode);
		}
		
	});

});
